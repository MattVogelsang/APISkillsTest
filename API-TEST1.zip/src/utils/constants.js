export const API_URL = 'https://fedskillstest.coalitiontechnologies.workers.dev';
export const USERNAME = 'coalition';
export const PASSWORD = 'skills-test';
