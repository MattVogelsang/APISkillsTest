function LoadingState() {
  return (
    <div className="loading-state">
      <p>Loading...</p>
    </div>
  );
}

export default LoadingState;
